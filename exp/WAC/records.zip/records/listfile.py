import os

# list all files in the subdirectories
# first to list the all subdirectories, then list all files in the subdirectories
def list_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            print(os.path.join(root, file))

# list_files('./')
import os
import re

def rename_files(directory):
    for root, dirs, files in os.walk(directory):
        for file in files:
            # Skip if the file is not a JSON file
            if not file.endswith('.json'):
                continue
            if file.find("_final") != -1:
            # Construct the full file path
                file_path = os.path.join(root, file)
                # Construct the new file path
                new_file_path = os.path.join(root, file.replace("_final", ""))
                
                # Rename the file
                os.rename(file_path, new_file_path)
                print(f"Renamed {file_path} to {new_file_path}")

# Change this to the directory containing your files
directory = './nopersona'
rename_files(directory)

directory = './persona'
rename_files(directory)

